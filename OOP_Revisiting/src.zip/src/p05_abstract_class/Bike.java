package p05_abstract_class;

public class Bike extends Vehicle {
    void move() {
        System.out.println("Bike is moving");
    }
}
