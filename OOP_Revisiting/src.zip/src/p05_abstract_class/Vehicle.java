package p05_abstract_class;

public abstract class Vehicle {
    abstract void move();

    void start() {
        System.out.println("Vehicle started");
    }
}
