package p05_abstract_class;

public class Main {
    public static void main(String[] args) {
        Vehicle v = new Bike();
        v.start();
        v.move();
    }
}
