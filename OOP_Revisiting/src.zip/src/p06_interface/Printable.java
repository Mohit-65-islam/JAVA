package p06_interface;

public interface Printable {
    void print();
}
