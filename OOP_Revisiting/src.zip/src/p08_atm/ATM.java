package p08_atm;

public class ATM {
    private int balance = 2000;

    public void deposit(int amount) {
        balance += amount;
        System.out.println("Deposited successfully");
    }

    public void withdraw(int amount) {
        if(amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn successfully");
        } else {
            System.out.println("Insufficient balance");
        }
    }

    public void showBalance() {
        System.out.println("Current Balance: " + balance);
    }
}
