package p02_access_modifiers;

public class Main {
    public static void main(String[] args) {
        Student s = new Student();
        s.setName("Anom");
        s.setRoll(61);
        System.out.println("Name: " + s.getName());
        System.out.println("Roll: " + s.getRoll());
    }
}
