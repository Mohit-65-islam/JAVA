package p02_access_modifiers;

public class Student {
    private String name;
    private int roll;

    public void setName(String n) {
        name = n;
    }

    public void setRoll(int r) {
        roll = r;
    }

    public String getName() {
        return name;
    }

    public int getRoll() {
        return roll;
    }
}
