package p01_classes_objects;

public class Main {
    public static void main(String[] args) {
        Book b1 = new Book();
        b1.title = "Java Basics";
        b1.price = 350;
        b1.showDetails();
    }
}
