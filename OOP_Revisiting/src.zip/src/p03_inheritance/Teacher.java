package p03_inheritance;

public class Teacher extends Person {
    void teach() {
        System.out.println(role + " is teaching.");
    }
}
