package p07_multiple_interface;

public interface Play {
    void game();
}
