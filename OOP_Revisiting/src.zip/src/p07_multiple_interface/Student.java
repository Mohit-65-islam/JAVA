package p07_multiple_interface;

public class Student implements Study, Play {
    public void read() {
        System.out.println("Student is studying");
    }

    public void game() {
        System.out.println("Student is playing");
    }
}
