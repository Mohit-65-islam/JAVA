package p07_multiple_interface;

public class Main {
    public static void main(String[] args) {
        Student s = new Student();
        s.read();
        s.game();
    }
}
