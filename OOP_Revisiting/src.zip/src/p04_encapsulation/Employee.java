package p04_encapsulation;

public class Employee {
    private double salary;

    public void addBonus(double amount) {
        if(amount > 0) salary += amount;
    }

    public double getSalary() {
        return salary;
    }
}
