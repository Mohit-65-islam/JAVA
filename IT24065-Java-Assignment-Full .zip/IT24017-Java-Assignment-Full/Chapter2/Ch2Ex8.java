import java.util.Scanner;
import java.util.Calendar;
public class Ch2Ex8 {
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    System.out.print("Enter timezone offset to GMT: ");
    int offset=input.nextInt();
    Calendar cal=Calendar.getInstance();
    long totalMillis=cal.getTimeInMillis() + offset*60*60*1000;
    int totalSeconds=(int)(totalMillis/1000%86400);
    int hour=totalSeconds/3600;
    int minute=totalSeconds/60%60;
    int second=totalSeconds%60;
    System.out.println("Current time is " + hour + ":" + minute + ":" + second);
  }
}