import java.util.Scanner;
public class Ch2Ex4 {
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    System.out.print("Enter pounds: ");
    double pounds=input.nextDouble();
    double kg=pounds*0.454;
    System.out.println(pounds + " pounds is " + kg + " kilograms");
  }
}